import './App.css'

function App() {
  return (
    <main className="shell">
      <div className="brand">Nexo</div>
      <section className="intro">
        <span className="eyebrow">Estrutura inicial</span>
        <h1>Gestão clara para o teu negócio.</h1>
        <p>O Nexo vai reunir vendas, stock, caixa e finanças numa plataforma preparada para funcionar online e offline.</p>
        <div className="status">Frontend pronto para a Etapa 0</div>
      </section>
    </main>
  )
}

export default App
