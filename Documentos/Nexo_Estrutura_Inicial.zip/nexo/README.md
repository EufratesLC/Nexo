# Nexo

Estrutura inicial da plataforma de gestão comercial e financeira. O nome é provisório. Nesta fase existem apenas uma página inicial e uma API de verificação. Vendas, stock, autenticação, Supabase e sincronização offline serão implementados nas etapas do roteiro.

## Requisitos

Node.js compatível com a versão do Vite indicada no `frontend/package.json` e npm.

## Iniciar no Windows PowerShell

Abre dois terminais na pasta `nexo`.

Terminal 1:

```powershell
cd frontend
npm install
npm run dev
```

Terminal 2:

```powershell
cd backend
Copy-Item .env.example .env
npm install
npm run dev
```

Abre o endereço indicado pelo Vite, normalmente `http://localhost:5173`. A API de verificação está em `http://localhost:3001/api/health`.

## Estrutura

```text
nexo/
├── frontend/        React, TypeScript e Vite
├── backend/         Express e TypeScript
├── .gitignore
└── README.md
```

## Próxima etapa

Especificar os requisitos e regras de negócio da Etapa 0 antes de criar a base de dados e os módulos.
